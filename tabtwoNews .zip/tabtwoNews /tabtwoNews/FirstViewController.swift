//
//  FirstViewController.swift
//  tabtwoNews
//november
//  Created by Bakyt Bakayeva on 11/06/20.
//  Copyright © 2020 Bakyt Bakayeva. All rights reserved.
//iOS developer


import UIKit

class FirstViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    

    @IBOutlet weak var tableView: UITableView!
    
// array contain all articles:
    var articles: [Article]? = []
    
    var source = "recode"
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
    //JSON
       fetchArticles(fromSource: source)
        // Do any additional setup after loading the view.
    }
    
    // JSON FETCH
   
    func fetchArticles(fromSource provider: String){
        // url request
        let appIDAdress = URLRequest(url: URL(string: "https://newsapi.org/v2/top-headlines?sources=\(provider)&apiKey=c73b3275d8fc42ed88cc464bbd10cf69")!)
        let task = URLSession.shared.dataTask(with: appIDAdress){(data, response, error) in
            if error != nil {
                print (error)
                return
            }
            // empty articles array
            self.articles = [Article]()
            // Json searialization: to insert do = catch
            
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String: AnyObject]
                if let articlesFromJson = json["articles"] as? [[String : AnyObject]]{
                    for articleFromJson in articlesFromJson{
                        let article = Article()
                        
                        if let title = articleFromJson["title"] as? String,
                        let author = articleFromJson["author"] as? String,
                            let desc = articleFromJson["description"] as? String,
                        let publishedAt = articleFromJson["publishedAt"] as? String,
                        let url = articleFromJson["url"] as? String,
                        let urlToImage = articleFromJson["urlToImage"] as? String
                            //let sourceName = articleFromJson["source"]["name"] as? String
                        {
                            // populate article object
                            article.author = author
                            article.headline = title
                            article.publishedAt = publishedAt
                            article.desc = desc
                            article.url=url
                            article.imageUrl=urlToImage
                            
                        }
                        self.articles?.append(article)
                    }
                    
                }
                // relload table view
                DispatchQueue.main.async {
                     self.tableView.reloadData()
                }
               
                
                
            } catch let error {
                print (error)
            }
            
            
        }
        task.resume()
        
    }
// CC working with cells
    // dd articleCell it is from table view identifier
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "articleCell", for: indexPath) as! ArticleCell
        
        
//        cell.title.text = "DFhhdfh dkgkg  lkdftuhlsku  dlkfguh"
//        cell.author.text = "Bakayeva"
//        cell.publishedAt.text = "dgdfgdfg This is a bana"
//
//        cell.desc.text = "dgsg,kxjfh xlfkhxf  dfgih;i df;ihhh ; sigh id  xifghxi  xgih xix x fgih; if d gbxlig    xlfihxfg d;f i; i x;ihj"
        
        // every article we put 1 cell
        cell.title.text = self.articles?[indexPath.item].headline
        cell.author.text = self.articles?[indexPath.item].author
        cell.desc.text = self.articles?[indexPath.item].desc
        cell.publishedAt.text = self.articles?[indexPath.item].publishedAt
//        cell.imgView.downloadImage(from: (self.articles?[indexPath.item].imageUrl!)!)
        //cell.imgView.downloadImage(url: (self.articles?[indexPath.item].imageUrl)!)
       // cell.imgView.downloadImage(url: (self.articles?[indexPath.item].imageUrl)!)
        cell.imgView.downloadImage(from: (self.articles?[indexPath.item].imageUrl!)!)
        
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  self.articles?.count ?? 0
    }
    
    //  method from table view
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let webVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(identifier: "web") as! ThirdViewController
        
        // url
        webVC.url = self.articles?[indexPath.item].url
        
        self.present(webVC, animated: true, completion: nil)
    }
    
    // oject menu manager
    let menuManager = MenuManager()
    
    @IBAction func menuPressed(_ sender: Any) {
        menuManager.openSources()
        menuManager.mainVC = self
    }
    
    
}
// image from web
extension UIImageView {
    func downloadImage(from url: String){
        // url request
        let urlImage = URLRequest(url: URL(string: url)!)
        let task = URLSession.shared.dataTask(with: urlImage){(data, response, error) in
            if error != nil {
                print (error)
                return
            }
            // to the main thread
            DispatchQueue.main.async {
                self.image = UIImage(data: data!)
            }
        }
        task.resume()
    }
}
