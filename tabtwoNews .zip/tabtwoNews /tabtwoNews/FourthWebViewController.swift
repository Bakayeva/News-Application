//
//  FourthWebViewController.swift
//  tabtwoNews
//
//  Created by Bakyt Bakayeva on 11/06/20.
//  Copyright © 2020 Bakyt Bakayeva. All rights reserved.
//

import UIKit

class FourthWebViewController: UIViewController {
    
    
    @IBOutlet weak var webView2: UIWebView!
    var url : String?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        webView2.loadRequest(URLRequest(url: URL(string: url!)!))
    
    }
    

}
