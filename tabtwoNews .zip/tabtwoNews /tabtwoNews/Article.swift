//
//  Article.swift
//  tabtwoNews
//
//  Created by Bakyt Bakayeva on 11/06/20.
//  Copyright © 2020 Bakyt Bakayeva. All rights reserved.
//

import UIKit

class Article: NSObject {
// from web json
    var headline : String? // title = headline
    var desc: String?  // desc= desc
    var author: String? // author= author
    var publishedAt: String? //pA = pA
    var imageUrl: String?
    var url: String?
    // AAA--- after that we need to connect with tableView
    
    
}
