//
//  SecondViewController.swift
//  tabtwoNews
//
//  Created by Bakyt Bakayeva on 11/06/20.
//  Copyright © 2020 Bakyt Bakayeva. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
  
    
    @IBOutlet weak var tableView2: UITableView!
    var articles2: [Article]? = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        view.backgroundColor = .white
        
        fetchArticles()
        
    }
    // fetch
    
    
    
    
    func fetchArticles(){
        let address = URLRequest(url: URL(string: "https://newsapi.org/v2/everything?q=apple&from=2020-11-12&to=2020-11-12&sortBy=popularity&apiKey=c73b3275d8fc42ed88cc464bbd10cf69")!)
        let task = URLSession.shared.dataTask(with: address){(data, response, error) in
            if error != nil{
                print (error)
                return
            }
            self.articles2 = [Article]()
            do{
                let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as! [String: AnyObject]
                if let articlesFromJSon = json["articles"] as? [[String : AnyObject]]{
                    for articleFromJson in articlesFromJSon {
                        
                        let article = Article()
                        if let title = articleFromJson["title"] as? String, let author = articleFromJson["author"] as? String,
                            let desc = articleFromJson["description"] as? String,
                        let publishedAt = articleFromJson["publishedAt"] as? String,
                        let url = articleFromJson["url"] as? String,
                            let urlToImage = articleFromJson["urlToImage"] as? String{
                            article.author = author
                            article.desc = desc
                            article.publishedAt = publishedAt
                            article.url = url
                            article.imageUrl = urlToImage
                            article.headline = title
                        }
                        self.articles2?.append(article)
                    }
                }
                DispatchQueue.main.async {
                    self.tableView2.reloadData()
                }
            }
            catch let error {
                print(error)
                
            }
            
        }
        task.resume()
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView2.dequeueReusableCell(withIdentifier: "articleCell2", for: indexPath) as! ArticleCell2
        cell.title2.text = self.articles2?[indexPath.item].headline
        
        cell.author2.text = self.articles2?[indexPath.item].author
        
        cell.desc2.text = self.articles2?[indexPath.item].desc
        
        cell.publishedAt2.text = self.articles2?[indexPath.item].publishedAt
        // for image
        cell.imgView2.download2Image(from: (self.articles2?[indexPath.item].imageUrl!)!)
        
        return cell
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.articles2?.count ?? 0
    }
    
    //  method from table view
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let webVCF = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(identifier: "web2") as! FourthWebViewController
        webVCF.url = self.articles2?[indexPath.item].url
        
        self.present(webVCF, animated: true, completion: nil)
    }

}

extension UIImageView {
    func download2Image(from url: String){
        // url request
        let urlImage = URLRequest(url: URL(string: url)!)
        let task = URLSession.shared.dataTask(with: urlImage){(data, response, error) in
            if error != nil {
                print (error)
                return
            }
            // to the main thread
            DispatchQueue.main.async {
                self.image = UIImage(data: data!)
            }
        }
        task.resume()
    }
}
