//
//  ArticleCell2.swift
//  tabtwoNews
//
//  Created by Bakyt Bakayeva on 11/06/20.
//  Copyright © 2020 Bakyt Bakayeva. All rights reserved.
//

import UIKit

class ArticleCell2: UITableViewCell {
    
    
    @IBOutlet weak var imgView2: UIImageView!
    
    
    @IBOutlet weak var title2: UILabel!
    
    @IBOutlet weak var desc2: UILabel!
    
    

    
    @IBOutlet weak var author2: UILabel!
  
    @IBOutlet weak var publishedAt2: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
